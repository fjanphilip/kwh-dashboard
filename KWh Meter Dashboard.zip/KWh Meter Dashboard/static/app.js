const $ = s => document.querySelector(s);
// Math.round(v*10^d)||0 membuang tanda minus pada nilai yang dibulatkan menjadi nol (mis. -0,4 W -> -0,00 kW)
const nf = (v, d = 0) => (Math.round(Number(v) * 10 ** d) / 10 ** d || 0)
  .toLocaleString('id-ID', { minimumFractionDigits: d, maximumFractionDigits: d });
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const DASH = '—';
const MODEL_LABEL = { pm5330: 'PM5330', sdm630: 'SDM630' };
const PHASE_MIN_V = 10; // di bawah ini fasa dianggap tidak terpasang / tidak bertegangan

const st = { page: 'dashboard', devices: [], area: 'all', q: '', openId: null, editId: null,
  conns: [], dbStatus: {}, editConnId: null, role: 'user', user: '',
  users: [], editUserId: null, dashArea: 'all', dashMetric: 'kw', trend: {} };

// ---------- API ----------
const AUTH_KEY = 'authToken';
const getToken = () => { try { return localStorage.getItem(AUTH_KEY) || ''; } catch { return ''; } };
const setToken = t => { try { t ? localStorage.setItem(AUTH_KEY, t) : localStorage.removeItem(AUTH_KEY); } catch { } };

async function api(path, opts = {}) {
  const token = getToken();
  const res = await fetch(path, { ...opts,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
    body: opts.body ? JSON.stringify(opts.body) : undefined });
  const json = await res.json().catch(() => ({}));
  if (res.status === 401) {
    setToken('');
    location.href = '/login.html';
    throw new Error('belum login');
  }
  if (!res.ok) throw new Error(json.error || `${path}: HTTP ${res.status}`);
  return json;
}
const load = async () => { st.devices = await api('/api/devices'); };

// ---------- notifikasi ----------
const toastEls = new Map();
function toast(key, msg, type = 'warn', sticky = false) {
  const box = $('#toasts');
  if (!box) return;
  let el = toastEls.get(key);
  if (!el) {
    el = document.createElement('div');
    el.innerHTML = '<div class="toast-msg"></div><button class="toast-x" aria-label="Tutup">×</button>';
    el.querySelector('.toast-x').onclick = () => { el.remove(); toastEls.delete(key); };
    box.appendChild(el);
    toastEls.set(key, el);
  }
  el.className = 'toast ' + type;
  el.querySelector('.toast-msg').textContent = msg;
  clearTimeout(el._timer);
  if (!sticky) el._timer = setTimeout(() => { el.remove(); toastEls.delete(key); }, 5000);
}
function clearToast(key) {
  const el = toastEls.get(key);
  if (el) { clearTimeout(el._timer); el.remove(); toastEls.delete(key); }
}

// ---------- turunan data ----------
const devId = d => 'PM-' + String(d.id).padStart(3, '0');
const sum = a => a.reduce((s, v) => s + (v ?? 0), 0);
const activePhases = d => d.live ? d.live.v.filter(v => v != null && v > PHASE_MIN_V).length : 0;

function summary(d) {
  const l = d.live;
  if (!l) return null;
  const vs = l.v.filter(v => v != null && v > PHASE_MIN_V);
  return { v: vs.length ? sum(vs) / vs.length : null, a: sum(l.i), kw: (l.p_total ?? sum(l.p)) / 1000,
    kva: (l.s_total ?? sum(l.s)) / 1000, freq: l.freq };
}

function status(d) {
  if (!d.enabled) return '<span class="pill off">Nonaktif</span>';
  if (!d.live) return `<span class="pill bad" title="${esc(d.error || 'menunggu data pertama')}">Offline</span>`;
  if (activePhases(d) < 3) return `<span class="pill warn">Fase tidak lengkap (${activePhases(d)}/3)</span>`;
  return '<span class="pill ok">Normal</span>';
}

// ---------- halaman Listrik ----------
function buildPage() {
  $('#page').innerHTML = `
  <div class="grid g4" id="kpi"></div>
  <div class="card mt">
    <div class="toolbar">
      <div class="tabs" id="area-tabs"></div>
      <span style="margin-left:auto"></span>
      <input id="q" placeholder="Cari titik…" style="width:200px">
      ${st.role === 'admin' ? '<button id="btn-add">+ Tambah perangkat</button>' : ''}
    </div>
    <div class="table-wrap"><table class="wide">
      <thead><tr><th>ID</th><th>Titik ukur</th><th>Area</th><th>Model</th><th>Modbus TCP</th><th class="num">Tegangan (V)</th><th class="num">Arus (A)</th>
        <th class="num">Daya (kW)</th><th class="num">Daya semu (kVA)</th><th class="num">Frekuensi (Hz)</th><th>Status</th><th></th></tr></thead>
      <tbody id="rows"></tbody>
    </table></div>
    <div class="muted small mt">Klik baris untuk melihat parameter real-time 3 fasa. Tegangan = rata-rata fasa yang bertegangan; arus, daya, dan daya semu = total 3 fasa.</div>
  </div>`;
  $('#q').oninput = e => { st.q = e.target.value; renderRows(); };
  const addBtn = $('#btn-add');
  if (addBtn) addBtn.onclick = () => openForm(null);
}

function renderAll() {
  renderKpi(); renderTabs(); renderRows(); renderDrawer();
}

function renderKpi() {
  const ok = st.devices.filter(d => d.live);
  const kw = sum(ok.map(d => summary(d).kw)), kva = sum(ok.map(d => summary(d).kva));
  const enabled = st.devices.filter(d => d.enabled).length;
  $('#kpi').innerHTML = `
    <div class="card kpi elec"><div class="label">Titik ukur</div><div class="value">${st.devices.length}</div><div class="sub">${enabled} aktif</div></div>
    <div class="card kpi elec"><div class="label">Meter online</div><div class="value">${ok.length}<span class="unit">/ ${enabled}</span></div></div>
    <div class="card kpi elec"><div class="label">Total daya saat ini</div><div class="value">${nf(kw, 2)}<span class="unit">kW</span></div></div>
    <div class="card kpi elec"><div class="label">Total daya semu</div><div class="value">${nf(kva, 2)}<span class="unit">kVA</span></div></div>`;
}

const areaKey = a => String(a || '').trim().toLowerCase();

// Gabungkan area yang beda kapitalisasi (mis. "Kitchen" & "kitchen") jadi satu tab.
// Label yang dipakai = ejaan yang paling sering muncul (tie-break alfabetis).
function areaGroups() {
  const groups = new Map();
  for (const d of st.devices) {
    const label = String(d.area || '').trim();
    if (!label) continue;
    const key = label.toLowerCase();
    const g = groups.get(key) || { key, counts: new Map() };
    g.counts.set(label, (g.counts.get(label) || 0) + 1);
    groups.set(key, g);
  }
  return [...groups.values()].map(g => {
    const entries = [...g.counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
    return { key: g.key, label: entries[0][0], count: entries.reduce((n, e) => n + e[1], 0) };
  }).sort((a, b) => a.label.localeCompare(b.label));
}

function renderTabs() {
  const groups = areaGroups();
  if (st.area !== 'all' && !groups.some(g => g.key === st.area)) st.area = 'all';
  $('#area-tabs').innerHTML = `<button data-a="all" class="${st.area === 'all' ? 'on' : ''}">Semua (${st.devices.length})</button>` +
    groups.map(g => `<button data-a="${esc(g.key)}" class="${st.area === g.key ? 'on' : ''}">${esc(g.label)} (${g.count})</button>`).join('');
  document.querySelectorAll('#area-tabs button').forEach(b => b.onclick = () => { st.area = b.dataset.a; renderTabs(); renderRows(); });
}

function renderRows() {
  const q = st.q.toLowerCase();
  const rows = st.devices.filter(d => (st.area === 'all' || areaKey(d.area) === st.area) &&
    (d.name + devId(d) + d.host).toLowerCase().includes(q));
  $('#rows').innerHTML = rows.length ? rows.map(d => {
    const s = summary(d), cell = (v, dec) => s && v != null ? nf(v, dec) : DASH;
    return `<tr class="click ${d.id === st.openId ? 'sel' : ''}" data-id="${d.id}"><td>${devId(d)}</td><td><strong>${esc(d.name)}</strong></td>
      <td>${esc(d.area) || DASH}</td><td>${MODEL_LABEL[d.model] || esc(d.model)}</td><td>${esc(d.host)}:${d.port} · #${d.unit_id}</td>
      <td class="num">${cell(s?.v, 1)}</td><td class="num">${cell(s?.a, 2)}</td>
      <td class="num"><strong>${cell(s?.kw, 2)}</strong></td><td class="num">${cell(s?.kva, 2)}</td>
      <td class="num">${cell(s?.freq, 2)}</td><td>${status(d)}</td>
      <td>${st.role === 'admin'
        ? '<button class="sm ghost" data-act="edit">Edit</button> <button class="sm danger" data-act="del">Hapus</button>'
        : ''}</td></tr>`;
  }).join('') : `<tr><td colspan="12" class="muted">${st.devices.length ? 'Tidak ada titik yang cocok.' : 'Belum ada perangkat. Klik “Tambah perangkat”.'}</td></tr>`;

  document.querySelectorAll('#rows tr.click').forEach(tr => {
    const d = st.devices.find(x => x.id === +tr.dataset.id);
    tr.onclick = () => { st.openId = d.id; $('#drawer').hidden = false; renderDrawer(); renderRows(); };
    const editBtn = tr.querySelector('[data-act=edit]');
    const delBtn = tr.querySelector('[data-act=del]');
    if (editBtn) editBtn.onclick = e => { e.stopPropagation(); openForm(d); };
    if (delBtn) delBtn.onclick = e => { e.stopPropagation(); removeDevice(d); };
  });
}

// ---------- right bar: parameter real-time ----------
function renderDrawer() {
  const d = st.devices.find(x => x.id === st.openId);
  if (!d) { $('#drawer').hidden = true; return; }
  const l = d.live, s = summary(d);
  $('#drawer-title').textContent = `${devId(d)} · ${d.name}`;

  const phaseRow = (label, unit, arr, total, dec) => `<tr><td>${label} <span class="muted small">${unit}</span></td>
    ${[0, 1, 2].map(k => `<td class="num">${l && arr[k] != null ? nf(arr[k], dec) : DASH}</td>`).join('')}
    <td class="num"><strong>${l && total != null ? nf(total, dec) : DASH}</strong></td></tr>`;
  const age = d.ts ? Math.max(0, Math.round(Date.now() / 1000 - d.ts)) : null;

  $('#drawer-body').innerHTML = `
    <div class="muted">${esc(d.area) || 'Tanpa area'} · ${MODEL_LABEL[d.model] || esc(d.model)} · ${esc(d.host)}:${d.port} · Unit ${d.unit_id} · ${d.function === 'input' ? 'FC4' : 'FC3'}</div>
    <div class="mt">${status(d)}${!l && d.error && d.enabled ? `<div class="muted small mt">${esc(d.error)}</div>` : ''}</div>
    <div class="grid g3 mt">
      <div class="tile"><div class="muted small">Daya</div><div class="v">${s ? nf(s.kw, 2) : DASH} <span class="unit">kW</span></div></div>
      <div class="tile"><div class="muted small">Daya semu</div><div class="v">${s ? nf(s.kva, 2) : DASH} <span class="unit">kVA</span></div></div>
      <div class="tile"><div class="muted small">Frekuensi</div><div class="v">${s && s.freq != null ? nf(s.freq, 2) : DASH} <span class="unit">Hz</span></div></div>
    </div>
    <div class="card mt"><h3>Parameter real-time <span class="muted small">${age != null ? 'diperbarui ' + age + ' detik lalu' : ''}</span></h3>
      <div class="table-wrap"><table class="drawer-table">
        <thead><tr><th>Parameter</th><th class="num">L1</th><th class="num">L2</th><th class="num">L3</th><th class="num">Total</th></tr></thead>
        <tbody>
          ${phaseRow('Tegangan', 'V', l?.v ?? [], s?.v, 1)}
          ${phaseRow('Arus', 'A', l?.i ?? [], s && s.a, 3)}
          ${phaseRow('Daya aktif', 'W', l?.p ?? [], l?.p_total, 1)}
          ${phaseRow('Daya semu', 'VA', l?.s ?? [], l?.s_total, 1)}
        </tbody></table></div>
      <div class="row mt"><span class="muted">Frekuensi</span><strong>${l && l.freq != null ? nf(l.freq, 2) + ' Hz' : DASH}</strong></div>
      <div class="muted small mt">Total tegangan = rata-rata fasa yang bertegangan (&gt; ${PHASE_MIN_V} V).</div>
    </div>
    ${st.role === 'admin' ? '<div class="toolbar mt"><button class="ghost" id="dr-edit">Edit</button><button class="danger" id="dr-del">Hapus</button></div>' : ''}`;
  const drEdit = $('#dr-edit'), drDel = $('#dr-del');
  if (drEdit) drEdit.onclick = () => openForm(d);
  if (drDel) drDel.onclick = () => removeDevice(d);
}

$('#drawer-close').onclick = () => { st.openId = null; $('#drawer').hidden = true; renderRows(); };
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#form-dlg').open) $('#drawer-close').click(); });

// ---------- CRUD ----------
const FORM_FIELDS = ['name', 'area', 'model', 'host', 'port', 'unit_id', 'function', 'byte_order', 'interval_s'];
const DEFAULTS = { name: '', area: '', model: 'pm5330', host: '', port: 502, unit_id: 1, function: 'holding', byte_order: 'big', interval_s: 2, enabled: true };
// Default pembacaan tiap model meter; dipakai saat model diganti di form.
const MODEL_DEFAULTS = { pm5330: { function: 'holding', byte_order: 'big' }, sdm630: { function: 'input', byte_order: 'big' } };
$('#f-model').onchange = e => Object.entries(MODEL_DEFAULTS[e.target.value]).forEach(([f, val]) => { $('#f-' + f).value = val; });

function openForm(d) {
  st.editId = d ? d.id : null;
  const v = d || DEFAULTS;
  $('#form-title').textContent = d ? `Edit ${devId(d)}` : 'Tambah perangkat';
  FORM_FIELDS.forEach(f => { $('#f-' + f).value = v[f]; });
  $('#f-enabled').checked = !!v.enabled;
  $('#form-err').hidden = true;
  $('#form-dlg').showModal();
}

$('#form-cancel').onclick = () => $('#form-dlg').close();
$('#form').onsubmit = async e => {
  e.preventDefault();
  const body = Object.fromEntries(FORM_FIELDS.map(f => [f, $('#f-' + f).value]));
  body.enabled = $('#f-enabled').checked;
  try {
    if (st.editId) await api('/api/devices/' + st.editId, { method: 'PUT', body });
    else st.openId = (await api('/api/devices', { method: 'POST', body })).id;
    $('#form-dlg').close();
    await load();
    if (st.openId) $('#drawer').hidden = false;
    renderAll();
  } catch (err) {
    $('#form-err').textContent = err.message; $('#form-err').hidden = false;
  }
};

async function removeDevice(d) {
  if (!confirm(`Hapus ${devId(d)} · ${d.name}? Konfigurasi perangkat akan hilang.`)) return;
  try {
    await api('/api/devices/' + d.id, { method: 'DELETE' });
    if (st.openId === d.id) st.openId = null;
    await load(); renderAll();
  } catch (err) { alert('Gagal menghapus: ' + err.message); }
}

// ---------- halaman Koneksi Database ----------
const loadConns = async () => { const r = await api('/api/db-connections'); st.conns = r.connections; st.dbStatus = r.status; };

function buildDatabase() {
  $('#page').innerHTML = `
  <div class="grid g4" id="db-kpi"></div>
  <div class="card mt">
    <div class="toolbar"><h3 style="margin:0">Koneksi database MySQL</h3><span style="margin-left:auto"></span>
      <button id="btn-add-conn">+ Tambah koneksi</button></div>
    <div class="table-wrap"><table class="wide">
      <thead><tr><th>Nama</th><th>Host : Port</th><th>Database</th><th>User</th><th class="num">Interval simpan</th><th>Status</th><th></th></tr></thead>
      <tbody id="conn-rows"></tbody>
    </table></div>
    <div class="muted small mt">Hanya satu koneksi yang aktif. Saat diaktifkan, database dan tabel <code>power_readings</code> dibuat otomatis bila belum ada,
      lalu pembacaan semua meter disimpan sesuai interval. Selama server database tidak terjangkau, data pada rentang itu tidak tersimpan.
      Password disimpan apa adanya di <code>meters.db</code> pada komputer ini dan tidak pernah dikirim kembali ke browser.</div>
  </div>`;
  $('#btn-add-conn').onclick = () => openConnForm(null);
}

function connStatus(c) {
  if (!c.active) return '<span class="pill off">Nonaktif</span>';
  const s = st.dbStatus;
  if (s.state === 'ok') return '<span class="pill ok">Terhubung · menyimpan</span>';
  if (s.state === 'error') return `<span class="pill bad" title="${esc(s.error || '')}">Gagal</span>`;
  return '<span class="pill warn">Menghubungkan…</span>';
}

function renderDb() {
  const active = st.conns.find(c => c.active), s = st.dbStatus;
  const last = s.last_write ? new Date(s.last_write * 1000).toLocaleTimeString('id-ID') : DASH;
  $('#db-kpi').innerHTML = `
    <div class="card kpi elec"><div class="label">Koneksi aktif</div><div class="value" style="font-size:20px">${active ? esc(active.name) : 'Tidak ada'}</div>
      <div class="sub">${active ? esc(active.host) + ' · ' + esc(active.db_name) : 'Aktifkan satu koneksi untuk mulai menyimpan'}</div></div>
    <div class="card kpi elec"><div class="label">Status</div><div class="value" style="font-size:20px">${active ? connStatus(active) : DASH}</div>
      <div class="sub">${s.state === 'error' ? esc(s.error) : '&nbsp;'}</div></div>
    <div class="card kpi elec"><div class="label">Terakhir menyimpan</div><div class="value" style="font-size:22px">${last}</div></div>
    <div class="card kpi elec"><div class="label">Baris tersimpan</div><div class="value">${nf(s.rows_total || 0)}</div><div class="sub">${s.pending ? nf(s.pending) + ' menunggu terkirim' : 'sejak koneksi diaktifkan'}</div></div>`;

  $('#conn-rows').innerHTML = st.conns.length ? st.conns.map(c => `<tr data-id="${c.id}">
    <td><strong>${esc(c.name)}</strong></td><td>${esc(c.host)}:${c.port}</td><td>${esc(c.db_name)}</td><td>${esc(c.db_user)}</td>
    <td class="num">${nf(c.store_interval_s, c.store_interval_s % 1 ? 1 : 0)} dtk</td><td>${connStatus(c)}</td>
    <td><button class="sm" data-act="toggle">${c.active ? 'Nonaktifkan' : 'Aktifkan'}</button>
      <button class="sm ghost" data-act="test">Tes</button> <button class="sm ghost" data-act="edit">Edit</button>
      <button class="sm danger" data-act="del">Hapus</button></td></tr>`).join('')
    : '<tr><td colspan="7" class="muted">Belum ada koneksi. Klik “Tambah koneksi”.</td></tr>';

  document.querySelectorAll('#conn-rows tr[data-id]').forEach(tr => {
    const c = st.conns.find(x => x.id === +tr.dataset.id);
    tr.querySelector('[data-act=edit]').onclick = () => openConnForm(c);
    tr.querySelector('[data-act=del]').onclick = () => removeConn(c);
    tr.querySelector('[data-act=toggle]').onclick = e => toggleConn(c, e.target);
    tr.querySelector('[data-act=test]').onclick = e => testSaved(c, e.target);
  });
}

async function refreshDb() { await loadConns(); renderDb(); }

async function toggleConn(c, btn) {
  btn.disabled = true; btn.textContent = 'Memproses…';
  try { await api(`/api/db-connections/${c.id}/${c.active ? 'deactivate' : 'activate'}`, { method: 'POST' }); }
  catch (err) { alert(err.message); }
  await refreshDb();
}

async function testSaved(c, btn) {
  btn.disabled = true; btn.textContent = 'Menguji…';
  try { alert(describeTest(await api('/api/db-connections/test', { method: 'POST', body: { ...c, id: c.id } }))); }
  catch (err) { alert(err.message); }
  btn.disabled = false; btn.textContent = 'Tes';
}

function describeTest(r) {
  if (!r.ok) return 'Gagal: ' + r.error;
  return `Terhubung ke server MySQL ${r.version}.\n` + (r.database_exists ? 'Database sudah ada.' : 'Database belum ada — akan dibuat saat koneksi diaktifkan.');
}

async function removeConn(c) {
  if (!confirm(`Hapus koneksi “${c.name}”?${c.active ? ' Penyimpanan data akan berhenti.' : ''}`)) return;
  try { await api('/api/db-connections/' + c.id, { method: 'DELETE' }); } catch (err) { alert(err.message); }
  await refreshDb();
}

const CONN_FIELDS = ['name', 'host', 'port', 'db_user', 'db_name', 'store_interval_s'];
const CONN_DEFAULTS = { name: '', host: '', port: 3306, db_user: '', db_name: 'ois_sosro_pw', store_interval_s: 60 };

function openConnForm(c) {
  st.editConnId = c ? c.id : null;
  const v = c || CONN_DEFAULTS;
  $('#db-form-title').textContent = c ? `Edit koneksi “${c.name}”` : 'Tambah koneksi database';
  CONN_FIELDS.forEach(f => { $('#c-' + f).value = v[f]; });
  $('#c-db_password').value = '';
  $('#c-pw-hint').hidden = !(c && c.has_password);
  $('#c-result').hidden = true;
  $('#db-dlg').showModal();
}

const connBody = () => ({ ...Object.fromEntries(CONN_FIELDS.map(f => [f, $('#c-' + f).value])),
  db_password: $('#c-db_password').value, id: st.editConnId });
function showConnResult(text, ok) { const el = $('#c-result'); el.textContent = text; el.className = 'form-msg ' + (ok ? 'ok' : 'bad'); el.hidden = false; }

$('#c-cancel').onclick = () => $('#db-dlg').close();
$('#c-test').onclick = async e => {
  e.target.disabled = true; showConnResult('Menguji koneksi…', true);
  try { const r = await api('/api/db-connections/test', { method: 'POST', body: connBody() }); showConnResult(describeTest(r), r.ok); }
  catch (err) { showConnResult(err.message, false); }
  e.target.disabled = false;
};
$('#db-form').onsubmit = async e => {
  e.preventDefault();
  try {
    const body = connBody();
    if (st.editConnId) await api('/api/db-connections/' + st.editConnId, { method: 'PUT', body });
    else await api('/api/db-connections', { method: 'POST', body });
    $('#db-dlg').close();
    await refreshDb();
  } catch (err) { showConnResult(err.message, false); }
};

// ---------- halaman Akun ----------
const loadUsers = async () => { st.users = await api('/api/users'); };

function buildAccounts() {
  $('#page').innerHTML = `
  <div class="card">
    <div class="toolbar"><h3 style="margin:0">Akun dashboard</h3></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Username</th><th>Role</th><th></th></tr></thead>
      <tbody id="user-rows"></tbody>
    </table></div>
    <div class="muted small mt">Password disimpan sebagai hash di <code>meters.db</code>. Setelah password diubah, sesi lama akun itu otomatis berakhir.</div>
  </div>`;
}

function renderAccounts() {
  $('#user-rows').innerHTML = st.users.length ? st.users.map(u => `<tr data-id="${u.id}">
    <td><strong>${esc(u.username)}</strong></td>
    <td>${u.role === 'admin' ? '<span class="pill ok">admin</span>' : '<span class="pill off">user</span>'}</td>
    <td><button class="sm ghost" data-act="pw">Ubah password</button></td></tr>`).join('')
    : '<tr><td colspan="3" class="muted">Belum ada akun.</td></tr>';

  document.querySelectorAll('#user-rows tr[data-id]').forEach(tr => {
    const u = st.users.find(x => x.id === +tr.dataset.id);
    tr.querySelector('[data-act=pw]').onclick = () => openAccForm(u);
  });
}

async function refreshAccounts() { await loadUsers(); renderAccounts(); }

function openAccForm(u) {
  st.editUserId = u.id;
  $('#acc-title').textContent = `Ubah password “${u.username}”`;
  $('#a-password').value = '';
  $('#acc-err').hidden = true;
  $('#acc-dlg').showModal();
  $('#a-password').focus();
}
$('#acc-cancel').onclick = () => $('#acc-dlg').close();
$('#acc-form').onsubmit = async e => {
  e.preventDefault();
  try {
    await api('/api/users/' + st.editUserId, { method: 'PUT', body: { password: $('#a-password').value } });
    $('#acc-dlg').close();
    await refreshAccounts();
  } catch (err) {
    const el = $('#acc-err'); el.textContent = err.message; el.hidden = false;
  }
};

// ---------- halaman Dashboard ----------
const DASH_METRICS = {
  kw: { label: 'Daya', unit: 'kW', dec: 2 },
  kva: { label: 'Daya semu', unit: 'kVA', dec: 2 },
  v: { label: 'Tegangan', unit: 'V', dec: 1 },
  a: { label: 'Arus', unit: 'A', dec: 2 },
};

// Ringkasan satu kelompok area. Tegangan & frekuensi = rata-rata antar meter; daya & arus = total.
function areaStats(devs) {
  const stats = devs.filter(d => d.live).map(summary).filter(Boolean);
  const vs = stats.map(s => s.v).filter(v => v != null);
  const fs = stats.map(s => s.freq).filter(f => f != null);
  return {
    kw: sum(stats.map(s => s.kw)),
    kva: sum(stats.map(s => s.kva)),
    a: sum(stats.map(s => s.a)),
    v: vs.length ? sum(vs) / vs.length : null,
    freq: fs.length ? sum(fs) / fs.length : null,
    online: stats.length,
    total: devs.length,
  };
}

const areaDevices = key => key === 'all' ? st.devices : st.devices.filter(d => areaKey(d.area) === key);

function buildDashboard() {
  $('#page').innerHTML = `
  <div class="grid g4" id="dash-kpi"></div>
  <div class="grid g2 mt">
    <div class="card">
      <h3><span id="dash-trend-title">Tren</span><span class="muted small">90 sampel terakhir</span></h3>
      <div class="chart-wrap"><canvas id="dash-trend"></canvas></div>
    </div>
    <div class="card">
      <h3>Perbandingan area <span class="muted small" id="dash-bar-unit"></span></h3>
      <div id="dash-bar"></div>
    </div>
  </div>
  <div class="card mt">
    <div class="toolbar">
      <h3 style="margin:0">Ringkasan per area</h3>
      <span style="margin-left:auto"></span>
      <div class="tabs" id="dash-metric"></div>
    </div>
    <div class="dash-areas" id="dash-areas"></div>
    <div class="muted small mt">Klik kartu area untuk melihat rincian meter di bawah; klik lagi untuk kembali ke semua area.</div>
  </div>
  <div class="card mt">
    <h3 id="dash-detail-title">Rincian semua area</h3>
    <div class="table-wrap"><table class="wide">
      <thead><tr><th>ID</th><th>Titik ukur</th><th>Area</th><th class="num">Tegangan (V)</th><th class="num">Arus (A)</th>
        <th class="num">Daya (kW)</th><th class="num">Daya semu (kVA)</th><th class="num">Frekuensi (Hz)</th><th>Status</th></tr></thead>
      <tbody id="dash-rows"></tbody>
    </table></div>
  </div>`;
}

function renderDashKpi() {
  const s = areaStats(st.devices);
  $('#dash-kpi').innerHTML = `
    <div class="card kpi elec"><div class="label">Total daya</div><div class="value">${nf(s.kw, 2)}<span class="unit">kW</span></div>
      <div class="sub">${s.online} dari ${s.total} meter online</div></div>
    <div class="card kpi elec"><div class="label">Total daya semu</div><div class="value">${nf(s.kva, 2)}<span class="unit">kVA</span></div>
      <div class="sub">seluruh area</div></div>
    <div class="card kpi elec"><div class="label">Tegangan rata-rata</div><div class="value">${s.v == null ? DASH : nf(s.v, 1)}<span class="unit">V</span></div>
      <div class="sub">fasa bertegangan</div></div>
    <div class="card kpi elec"><div class="label">Total arus</div><div class="value">${nf(s.a, 2)}<span class="unit">A</span></div>
      <div class="sub">${s.freq == null ? 'frekuensi —' : 'frekuensi ' + nf(s.freq, 2) + ' Hz'}</div></div>`;
}

function renderDashAreas() {
  const groups = areaGroups();
  if (st.dashArea !== 'all' && !groups.some(g => g.key === st.dashArea)) st.dashArea = 'all';
  $('#dash-metric').innerHTML = Object.entries(DASH_METRICS).map(([k, m]) =>
    `<button data-m="${k}" class="${st.dashMetric === k ? 'on' : ''}">${m.label}</button>`).join('');
  $('#dash-metric').querySelectorAll('button').forEach(b => b.onclick = () => {
    st.dashMetric = b.dataset.m;
    recordTrend();
    renderDashAreas(); renderDashCharts();
  });

  const m = DASH_METRICS[st.dashMetric];
  const stats = groups.map(g => ({ ...g, s: areaStats(areaDevices(g.key)) }));
  const max = Math.max(1e-9, ...stats.map(x => Math.abs(x.s[st.dashMetric] ?? 0)));
  $('#dash-areas').innerHTML = stats.length ? stats.map(x => {
    const val = x.s[st.dashMetric];
    const pct = Math.max(0, Math.min(100, Math.abs(val ?? 0) / max * 100));
    return `<button class="area-card ${st.dashArea === x.key ? 'on' : ''}" data-k="${esc(x.key)}">
      <div class="area-head"><strong>${esc(x.label)}</strong><span class="muted small">${x.s.online}/${x.s.total} online</span></div>
      <div class="area-main">${val == null ? DASH : nf(val, m.dec)} <span class="unit">${m.unit}</span></div>
      <div class="bar"><span style="width:${pct}%"></span></div>
      <div class="area-sub muted small">kW ${nf(x.s.kw, 2)} · kVA ${nf(x.s.kva, 2)} · V ${x.s.v == null ? DASH : nf(x.s.v, 1)} · A ${nf(x.s.a, 2)}</div>
    </button>`;
  }).join('') : '<div class="muted">Belum ada area. Tambahkan perangkat dengan area terisi.</div>';

  $('#dash-areas').querySelectorAll('.area-card').forEach(el => el.onclick = () => {
    st.dashArea = st.dashArea === el.dataset.k ? 'all' : el.dataset.k;
    recordTrend();
    renderDashAreas(); renderDashCharts(); renderDashDetail();
  });
}

// ---------- grafik (canvas/SVG murni, tanpa library) ----------
const trendKey = () => st.dashArea + '|' + st.dashMetric;

function recordTrend() {
  const value = areaStats(areaDevices(st.dashArea))[st.dashMetric];
  const key = trendKey();
  const series = st.trend[key] || (st.trend[key] = []);
  series.push({ t: Date.now(), v: value });
  if (series.length > 90) series.splice(0, series.length - 90);
}

function drawTrendChart() {
  const canvas = $('#dash-trend');
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const w = Math.max(240, rect.width), h = Math.max(140, rect.height || 220);
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const g = canvas.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);

  const m = DASH_METRICS[st.dashMetric];
  const series = (st.trend[trendKey()] || []).filter(p => p.v != null && isFinite(p.v));
  const pad = { l: 52, r: 12, t: 12, b: 24 };
  const cw = w - pad.l - pad.r, ch = h - pad.t - pad.b;

  if (!series.length) {
    g.fillStyle = '#5b6b7f'; g.font = '12px Segoe UI'; g.textAlign = 'center';
    g.fillText('Mengumpulkan data…', w / 2, h / 2);
    g.textAlign = 'start';
    return;
  }

  let min = Math.min(...series.map(p => p.v)), max = Math.max(...series.map(p => p.v));
  if (max - min < 1e-9) { max += Math.abs(max) * 0.05 || 1; min -= Math.abs(min) * 0.05 || 1; }
  const span = max - min, lo = min - span * 0.08, hi = max + span * 0.08;
  const x = i => pad.l + (series.length === 1 ? cw / 2 : cw * i / (series.length - 1));
  const y = v => pad.t + ch * (1 - (v - lo) / (hi - lo));

  g.strokeStyle = '#e6ecf3'; g.fillStyle = '#5b6b7f'; g.font = '11px Segoe UI'; g.lineWidth = 1;
  for (let k = 0; k <= 4; k++) {
    const yy = pad.t + ch * k / 4;
    g.beginPath(); g.moveTo(pad.l, yy); g.lineTo(pad.l + cw, yy); g.stroke();
    g.fillText(nf(hi - (hi - lo) * k / 4, m.dec), 6, yy + 3);
  }

  g.beginPath();
  series.forEach((p, i) => { const px = x(i), py = y(p.v); i ? g.lineTo(px, py) : g.moveTo(px, py); });
  g.lineTo(x(series.length - 1), pad.t + ch);
  g.lineTo(x(0), pad.t + ch);
  g.closePath();
  const grad = g.createLinearGradient(0, pad.t, 0, pad.t + ch);
  grad.addColorStop(0, 'rgba(13,127,115,.22)');
  grad.addColorStop(1, 'rgba(13,127,115,0)');
  g.fillStyle = grad; g.fill();

  g.beginPath();
  series.forEach((p, i) => { const px = x(i), py = y(p.v); i ? g.lineTo(px, py) : g.moveTo(px, py); });
  g.strokeStyle = '#0d7f73'; g.lineWidth = 2; g.stroke();

  const last = series[series.length - 1];
  g.beginPath(); g.arc(x(series.length - 1), y(last.v), 3.5, 0, Math.PI * 2);
  g.fillStyle = '#0d7f73'; g.fill();

  g.fillStyle = '#5b6b7f'; g.font = '11px Segoe UI'; g.textAlign = 'right';
  g.fillText(`${series.length} sampel · ${m.unit}`, w - pad.r, h - 6);
  g.textAlign = 'start';
}

function renderAreaBars(stats) {
  const box = $('#dash-bar');
  if (!box) return;
  const m = DASH_METRICS[st.dashMetric];
  const unit = $('#dash-bar-unit');
  if (unit) unit.textContent = m.unit;
  if (!stats.length) { box.innerHTML = '<div class="muted small">Belum ada area.</div>'; return; }

  const max = Math.max(1e-9, ...stats.map(x => Math.abs(x.s[st.dashMetric] ?? 0)));
  const rowH = 28, labelW = 120, barMax = 380, valueW = 64;
  const width = labelW + barMax + valueW, height = stats.length * rowH + 6;
  box.innerHTML = `<svg viewBox="0 0 ${width} ${height}" class="bar-svg" role="img">
    ${stats.map((x, i) => {
      const val = x.s[st.dashMetric];
      const len = Math.max(0, Math.min(1, Math.abs(val ?? 0) / max)) * barMax;
      const yy = i * rowH + 4;
      return `<g data-k="${esc(x.key)}">
        <title>${esc(x.label)}: ${val == null ? DASH : nf(val, m.dec) + ' ' + m.unit}</title>
        <text x="0" y="${yy + 16}" class="bar-label">${esc(x.label)}</text>
        <rect x="${labelW}" y="${yy + 4}" width="${barMax}" height="18" rx="4" class="bar-track"/>
        <rect x="${labelW}" y="${yy + 4}" width="${len}" height="18" rx="4" class="bar-fill"/>
        <text x="${labelW + barMax + 8}" y="${yy + 17}" class="bar-value">${val == null ? DASH : nf(val, m.dec)}</text>
      </g>`;
    }).join('')}
  </svg>`;

  box.querySelectorAll('g[data-k]').forEach(el => el.onclick = () => {
    st.dashArea = st.dashArea === el.dataset.k ? 'all' : el.dataset.k;
    recordTrend();
    renderDashAreas(); renderDashCharts(); renderDashDetail();
  });
}

function renderDashCharts() {
  const m = DASH_METRICS[st.dashMetric];
  const g = areaGroups().find(x => x.key === st.dashArea);
  const title = $('#dash-trend-title');
  if (title) title.textContent = `Tren ${m.label.toLowerCase()} — ${st.dashArea === 'all' ? 'semua area' : (g ? g.label : st.dashArea)}`;
  drawTrendChart();
  renderAreaBars(areaGroups().map(gr => ({ ...gr, s: areaStats(areaDevices(gr.key)) })));
}

function renderDashDetail() {
  const g = areaGroups().find(x => x.key === st.dashArea);
  const devs = areaDevices(st.dashArea);
  $('#dash-detail-title').textContent = st.dashArea === 'all'
    ? 'Rincian semua area' : `Rincian area ${g ? g.label : st.dashArea}`;
  $('#dash-rows').innerHTML = devs.length ? devs.map(d => {
    const s = summary(d), cell = (v, dec) => s && v != null ? nf(v, dec) : DASH;
    return `<tr><td>${devId(d)}</td><td><strong>${esc(d.name)}</strong></td><td>${esc(d.area) || DASH}</td>
      <td class="num">${cell(s?.v, 1)}</td><td class="num">${cell(s?.a, 2)}</td>
      <td class="num"><strong>${cell(s?.kw, 2)}</strong></td><td class="num">${cell(s?.kva, 2)}</td>
      <td class="num">${cell(s?.freq, 2)}</td><td>${status(d)}</td></tr>`;
  }).join('') : '<tr><td colspan="9" class="muted">Tidak ada perangkat pada area ini.</td></tr>';
}

async function refreshDashboard() {
  await load();
  recordTrend();
  renderDashKpi();
  renderDashAreas();
  renderDashCharts();
  renderDashDetail();
}

// ---------- router ----------
const PAGES = {
  dashboard: { title: 'Dashboard', build: buildDashboard, refresh: refreshDashboard, first: refreshDashboard },
  listrik: { title: 'Listrik', build: buildPage, refresh: async () => { await load(); renderKpi(); renderRows(); renderDrawer(); },
    first: async () => { await load(); renderAll(); } },
  database: { title: 'Koneksi Database', build: buildDatabase, refresh: refreshDb, first: refreshDb },
  akun: { title: 'Akun', build: buildAccounts, refresh: refreshAccounts, first: refreshAccounts },
};

async function go() {
  const page = (location.hash || '#dashboard').slice(1);
  st.page = PAGES[page] ? page : 'dashboard';
  if ((st.page === 'database' || st.page === 'akun') && st.role !== 'admin') { location.hash = '#dashboard'; return; }
  const p = PAGES[st.page];
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('active', a.dataset.page === st.page));
  $('#page-title').textContent = p.title;
  st.openId = null;
  $('#drawer').hidden = true;
  p.build();
  try { await p.first(); } catch (e) { showBackendError(e); }
}

function showBackendError(e) {
  $('#page').innerHTML = `<div class="card"><h3>Tidak dapat terhubung ke backend</h3><p class="muted">${esc(e.message)}</p>
    <p>Jalankan <code>python server.py</code> di folder <code>dashboard</code>.</p></div>`;
}

// ---------- start ----------
setInterval(() => { $('#clock').textContent = new Date().toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'medium' }); }, 1000);
window.addEventListener('hashchange', go);
window.addEventListener('resize', () => { if (st.page === 'dashboard') renderDashCharts(); });
$('#data-source').textContent = 'Sumber: Modbus TCP langsung';

// ---------- menu samping (tablet/mobile) ----------
const menuBtn = $('#menu-toggle');
const navOverlay = $('#nav-overlay');
function setNav(open) {
  document.body.classList.toggle('nav-open', open);
  const sidebar = document.querySelector('.sidebar');
  if (sidebar) sidebar.classList.toggle('open', open);
  if (menuBtn) menuBtn.setAttribute('aria-expanded', String(open));
}
if (menuBtn) menuBtn.onclick = () => setNav(!document.body.classList.contains('nav-open'));
if (navOverlay) navOverlay.onclick = () => setNav(false);
document.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => setNav(false)));
document.addEventListener('keydown', e => { if (e.key === 'Escape') setNav(false); });
window.addEventListener('resize', () => { if (window.innerWidth > 820) setNav(false); });

const logoutBtn = $('#logout');
if (logoutBtn) logoutBtn.onclick = async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch { /* sesi mungkin sudah habis */ }
  setToken('');
  location.href = '/login.html';
};

async function init() {
  try {
    const me = await api('/api/me');
    st.role = me.role; st.user = me.username;
  } catch { return; } // 401 sudah diarahkan ke login oleh api()
  document.querySelectorAll('[data-admin-only]').forEach(el => { el.hidden = st.role !== 'admin'; });
  const who = $('#whoami');
  if (who) who.textContent = `${st.user} (${st.role})`;
  go();
}

// ---------- pemantauan koneksi ----------
let lastDbState = null;
function watchDb(db) {
  if (!db) return;
  if (db.state === 'error') {
    toast('db', 'Koneksi database terputus: ' + (db.error || 'tidak diketahui') + '. Data ditahan di buffer lokal.', 'bad', true);
  } else if (db.state === 'ok') {
    if (lastDbState === 'error') toast('db-ok', 'Koneksi database pulih. Data buffer dikirim ulang.', 'ok');
    clearToast('db');
  } else {
    clearToast('db');
  }
  lastDbState = db.state;
}

let statusFails = 0;
async function monitorStatus() {
  if (!st.user) return; // belum login / sesi masih dimuat
  try {
    const s = await api('/api/status');
    statusFails = 0;
    clearToast('net');
    watchDb(s.db);
  } catch (e) {
    if (e.message === 'belum login') return;
    statusFails += 1;
    if (statusFails >= 2) toast('net', 'Tidak dapat terhubung ke server dashboard. Mencoba lagi…', 'bad', true);
  }
}

init();
setInterval(monitorStatus, 3000);
setInterval(async () => {
  if (!st.user) return; // belum login / masih memuat sesi
  if (document.querySelector('dialog[open]')) return; // jangan ganggu form yang sedang diisi
  try { await PAGES[st.page].refresh(); } catch { /* backend sementara putus; coba lagi pada siklus berikutnya */ }
}, 2000);
