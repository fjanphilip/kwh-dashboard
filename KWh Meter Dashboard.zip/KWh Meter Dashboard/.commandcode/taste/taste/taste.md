# Taste
- Testing must always run on port 3389 ("selalu jalankan di port 3389"); use that fixed port for any local test server instead of picking another one. Confidence: 0.85
- For actions requiring elevated/admin rights, prefers to run the commands himself: hand over copy-pasteable command blocks instead of attempting the operation in-session. Confidence: 0.6
- The app must work fully offline: avoid CDNs (and external assets like web fonts/@import) for styling and everything else; use vanilla/inline implementations instead of pulling libraries from the network. Confidence: 0.85
- Designs for real continuous factory operation: login sessions must not force periodic re-login or be lost on server restart (prefers persistent/sliding sessions, configurable duration). Confidence: 0.6
- For responsive/mobile layouts, prefers a hamburger button + off-canvas sliding sidebar (with overlay) over turning the sidebar into a horizontal scrollable top nav bar. Confidence: 0.6
- Wants documentation (e.g. README) kept concise and bullet-pointed rather than long prose ("ringkas dan poin poin"). Confidence: 0.6
- Expects work to stay strictly inside the scope he specified (e.g. only the roles/accounts he asked for) and objects to extra roles, test accounts, or artifacts appearing beyond that; prefers fewer features over more — tells you to delete functionality he didn't ask for rather than keep it around. Confidence: 0.8
