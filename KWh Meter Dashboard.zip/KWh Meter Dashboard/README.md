# SOSRO Dashboard

Dashboard listrik realtime (Modbus TCP, 3 fasa). Backend `server.py` (Python stdlib + pymodbus), frontend statis di `static/`. Konfigurasi meter & koneksi MySQL disimpan di `meters.db` (SQLite, dibuat otomatis, tidak di-commit).

```
Meter --Modbus--> server.py --> outbox (SQLite, buffer lokal) --> MySQL pabrik
                      \--> browser (Dashboard/Listrik)
```

## Prasyarat
- Python 3 (jalankan lewat `.venv` yang dibuat setup).
- MySQL/MariaDB bila data mau disimpan ke server pabrik (mis. XAMPP).
- Port bebas: `8080` (default), atau `3389` bila 8080 diblokir antivirus/firewall.

## Setup awal (sekali per mini PC)
- Buka folder project di cmd/PowerShell.
- Tanpa MySQL (hanya konfigurasi lokal):
  ```
  setup.bat --source <nama-mini-pc>
  ```
- Dengan MySQL:
  ```
  setup.bat --source minipc-gudang1 --mysql-host 127.0.0.1 --mysql-user root
  ```
- `--source`: nama unik mini PC (disimpan di setiap baris data; beberapa mini PC boleh kirim ke satu MySQL).
- `--mysql-user`: satu user MySQL dengan hak CREATE/ALTER pada database dashboard. User ini dipakai saat setup dan saat server berjalan.
- Password MySQL ditanya saat setup atau lewat env `MYSQL_PASSWORD`.
- Setup akan: membuat `.venv`, install `requirements.txt`, membuat `meters.db`, (opsional) membuat database `ois_sosro_pw` + tabel `power_readings`, lalu menyimpan & mengaktifkan koneksi.
- Akun dashboard dibuat otomatis: `admin` / `admin123` dan `user` / `user123`. Bisa diganti via env `DASHBOARD_ADMIN_PASSWORD` / `DASHBOARD_USER_PASSWORD`.
- Segera ganti password lewat menu **Akun** setelah login.
- Lupa password akun:
  ```
  setup.bat --admin-password PasswordBaru --user-password PasswordBaru
  ```

## Start server
- Jalankan:
  ```
  .venv\Scripts\python server.py --host 0.0.0.0 --port 8080
  ```
- Buka `http://<ip-mini-pc>:8080` lalu login.
- Bila 8080 diblokir , pakai port yang diizinkan:
  ```
  .venv\Scripts\python server.py --host 0.0.0.0 --port 3389
  ```
- Hanya satu instance per `meters.db`; proses kedua menolak start (file lock).
- Auto-start: Windows Task Scheduler, trigger “At startup”, “Run whether user is logged on or not”, restart saat gagal.
- Update aplikasi: `git pull` lalu restart server.

## Halaman & hak akses
- **Dashboard** — ringkasan total & per area, grafik tren real-time dan perbandingan area. Semua role.
- **Listrik** — tabel per meter + parameter 3 fasa. Semua role; tambah/edit/hapus hanya `admin`.
- **Koneksi Database** & **Akun** — khusus `admin`.
- `user` hanya baca (API juga menolak operasi tulis).

## Operasional ringkas
- **Firewall**: batasi port hanya untuk IP yang perlu.
  `netsh advfirewall firewall add rule name="SOSRO Dashboard" dir=in action=allow protocol=TCP localport=8080 remoteip=192.168.1.0/24`
- **Backup**: `meters.db` berisi password MySQL; batasi akses file. Saat backup, ikutkan `meters.db-wal`/`-shm` atau hentikan server dulu.
- **Buffer**: saat MySQL/jaringan putus, data tertahan di outbox (maks. 500.000 baris) dan dikirim otomatis saat pulih. Statusnya tampil di halaman Database.
- **Warning**: dashboard menampilkan popup bila koneksi MySQL terputus/pulih (dicek tiap ±5 detik).
- **Log**: `dashboard.log` (berputar).
- **Jam**: aktifkan NTP dan samakan zona waktu dengan server pabrik.
- **Stop MySQL** via XAMPP/`mysqladmin shutdown`, jangan kill proses, agar tabel tidak korup.
